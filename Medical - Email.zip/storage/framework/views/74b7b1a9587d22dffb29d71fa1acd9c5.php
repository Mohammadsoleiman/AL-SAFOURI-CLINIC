<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','create'); ?>

<div class="card ">
  <div class="card-header">Specialty Page</div>
  <div class="card-body">

      <form action="<?php echo e(route('specialtys.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label>SpeciatlyName</label></br>
        <input type="text" name="namesep" id="name" class="form-control">
        <label>DoctorName</label></br>

        <select  name="user_id" class="form-control" >
<?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($name->role=='doctor'): ?>
<option value="<?php echo e($name->id); ?>"><?php echo e($name->name); ?></option>

<?php endif; ?>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select><br>


        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical\resources\views/admin/specialty/create.blade.php ENDPATH**/ ?>