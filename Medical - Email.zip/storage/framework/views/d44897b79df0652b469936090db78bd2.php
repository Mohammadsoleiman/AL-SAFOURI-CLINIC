<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','create'); ?>

<div class="card">
  <div class="card-header">Edit Page</div>
  <div class="card-body">

      <form action="<?php echo e(url('pharmacys/' .$pharmacys->id)); ?> " method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PUT"); ?>
        <label>Name</label></br>
        <input type="text" name="name" id="name" class="form-control" value="<?php echo e($pharmacys->name); ?>"></br>
        <label>Production Date</label></br>
        <input type="Date" name="production_date" id="address" class="form-control" value="<?php echo e($pharmacys->production_date); ?>"></br>
        <label>End Date</label></br>
        <input type="Date" name="end_date" id="mobile" class="form-control" value="<?php echo e($pharmacys->end_date); ?>"></br>
        <label>Amount</label></br>
        <input type="number" name="amount" id="mobile" class="form-control" value="<?php echo e($pharmacys->amount); ?>"></br>
        <label>Price</label></br>
        <input type="number" name="price" id="mobile" class="form-control" value="<?php echo e($pharmacys->price); ?>"></br>


        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>


  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical - Email\resources\views/admin/pharmacy/edit.blade.php ENDPATH**/ ?>