<?php $__env->startSection( 'content' ); ?>
<div class="formbold-main-wrapper">
    <!-- Author: FormBold Team -->
    <!-- Learn More: https://formbold.com -->
    <div class="formbold-form-wrapper">

    <?php if(session('success')): ?>
        <div class="alert alert-success"style="padding: 5px"  role="alert">
     <?php echo e(session( 'success' )); ?>

        </div>
<?php elseif(session('failure')): ?>
<div class="alert alert-danger" style="padding: 5px" role="alert">
<?php echo e(session( 'failure' )); ?>

</div>
        <?php endif; ?>

        <form action="<?php echo e(route('transfer.data', $appointment->id)); ?>"method="POST">
            <?php echo csrf_field(); ?>



            <div class="formbold-mb-5">
                                <label for="name" class="formbold-form-label"> Report </label>

                                <textarea type="text" name="detail" id="name"  class="formbold-form-input" ></textarea>
                                <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

            <div>
                <button class="formbold-btn" type="submit"> Appointment</button>
            </div>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('doctor.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical - Email\resources\views/user/appointment/edit.blade.php ENDPATH**/ ?>