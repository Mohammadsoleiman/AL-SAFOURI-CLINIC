<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','edit'); ?>

<div class="card">
  <div class="card-header">Edit Page</div>
  <div class="card-body">

      <form action="<?php echo e(url('users/' .$users->id)); ?> " method="post"  enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PUT"); ?>
        <input type="hidden" name="id" id="id" value="<?php echo e($users->id); ?>" id="id" />
        <label>Name</label></br>
        <input type="text" name="name" id="name" value="<?php echo e($users->name); ?>" class="form-control"></br>
        <label>Address</label></br>
        <input type="text" name="email" id="email" value="<?php echo e($users->email); ?>" class="form-control"></br>
        <label>Mobile</label></br>
        <input type="text" name="phone" id="phone" value="<?php echo e($users->phone); ?>" class="form-control"></br>
        <label>Gender</label></br></br>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" value="Male " >
            <label class="form-check-label" for="inlineRadio1">Male</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" id="inlineRadio2" value="Female">
            <label class="form-check-label" for="inlineRadio2">Female</label>
          </div></br></br>

            </br>
        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>