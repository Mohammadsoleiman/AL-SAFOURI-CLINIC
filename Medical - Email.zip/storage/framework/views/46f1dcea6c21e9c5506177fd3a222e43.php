<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','create'); ?>

<div class="card">
  <div class="card-header">Pharmacy Page</div>
  <div class="card-body">

      <form action="<?php echo e(route('pharmacys.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label>Name</label></br>
        <input type="text" name="name" id="name" class="form-control"></br>
        <label>Production Date</label></br>
        <input type="Date" name="production_date" id="address" class="form-control"></br>
        <label>End Date</label></br>
        <input type="Date" name="end_date" id="mobile" class="form-control"></br>
        <label>Amount</label></br>
        <input type="number" name="amount" id="mobile" class="form-control"></br>
        <label>Price</label></br>
        <input type="number" name="price" id="mobile" class="form-control"></br>

        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical\resources\views/admin/pharmacy/create.blade.php ENDPATH**/ ?>