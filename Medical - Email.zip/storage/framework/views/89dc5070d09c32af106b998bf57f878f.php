<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','create'); ?>

                <div class="card h-100">
                    <div class="card-header p-0 mx-1">
                        <h4>Message</h4>
                    </div>
                    <div class="card-body">

<br>
                        <form method="GET" action="/searchm">
                            <div class="input-group d-flex justify-content-end">
                                <div class="form-outline" data-mdb-input-init>
                                  <input type="search" id="form1" class="form-control" name="search"  placeholder="Search"  value="<?php echo e(isset($search)? $search :''); ?>"/>
                                </div>
                                <button type="submit"  class="btn-search" data-mdb-ripple-init>
                                  <i class="fas fa-search"></i>
                                </button>
                              </div>
                            </form>

                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Subject</th>
                                        <th>Message	</th><br>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td data-title='ID'><?php echo e($loop->iteration); ?></td>
                                        <td data-title='Name'><?php echo e($item->name); ?></td>
                                        <td data-title='Email'><?php echo e($item->email); ?></td>
                                        <td data-title='Subject'><?php echo e($item->subject); ?></td>
                                        <td data-title='Message'><?php echo e($item->message); ?></td>


                                        <td data-title='Actiona'>
                                            <form method="POST" action="<?php echo e(url('/messages' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete Teacher" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <div> <?php echo e($messages->links('pagination::bootstrap-5')); ?></div>

                        </div>

                    </div>
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical - Email\resources\views/admin/message/index.blade.php ENDPATH**/ ?>