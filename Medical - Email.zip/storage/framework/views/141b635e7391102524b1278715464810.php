<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','Doctor'); ?>

                <div class="card ">
                    <div class="card-header ">
                        <h2>All Doctor</h2>
                    </div>
                    <div class="card-body ">
                         <a href="<?php echo e(route('doctors.create')); ?>" class="btn btn-success btn-sm" title="Add New Student">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add Doctor
                        </a>
                         <a href="<?php echo e(route('specialtys.index')); ?>" class="btn btn-success btn-sm" title="Add New Student">
                            <i class="fa fa-plus" aria-hidden="true"></i> Specialty
                        </a>

                        <br/>
                        <form method="GET" action="/search" >
                        <div class="input-group d-flex justify-content-end">
                            <div class="form-outline" data-mdb-input-init>
                              <input type="search" id="form1" class="form-control" name="search"  placeholder="Search"  value="<?php echo e(isset($search)? $search :''); ?>"/>
                            </div>
                            <button type="submit" class="btn btn-primary" data-mdb-ripple-init>
                              <i class="fas fa-search"></i>
                            </button>
                          </div>
                        </form class="w-50">
                        <div class="table-responsive ">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>id</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        
                                        <th>Specialty</th>
                                        
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->role =='doctor'): ?>


                                    <tr>

                                        <td><?php echo e($item->id); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td >   <?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->phone); ?></td>
                                        

                                        <?php $__currentLoopData = $add; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($row->namesep); ?></td>
                                            <?php break; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <td><?php echo e($item->created_at); ?></td>


                                        <td>

                                            <a href="<?php echo e(url('/doctors/' . $item->id . '/edit')); ?>" title="Edit user"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>

                                            <form method="POST" action="<?php echo e(url('/doctors' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete user" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                            </form>
                                        </td>

                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>


                            </table>
                           <div> <?php echo e($doctors->links('pagination::bootstrap-5')); ?></div>

                        </div>

                    </div>
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical\resources\views/admin/doctor/index.blade.php ENDPATH**/ ?>