<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','create'); ?>

                <div class="card h-100">
                    <div class="card-header p-0 mx-1">
                        <h4>Pharmacy</h4>
                    </div>
                    <div class="card-body pt-3">
                        <a href="<?php echo e(route('pharmacys.create')); ?>" class="btn btn-success btn-sm" id="add" title="Add New Teacher">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>
                        <br/>
                        <br/>
                        <br/>

                        <form method="GET" action="/searchp">
                            <div class="input-group d-flex justify-content-end pt-0">
                                <div class="form-outline" data-mdb-input-init>
                                  <input type="search" id="form1" class="form-control" name="search"  placeholder="Search"  value="<?php echo e(isset($search)? $search :''); ?>"/>
                                </div>
                                <button type="submit" class="btn-search" data-mdb-ripple-init>
                                  <i class="fas fa-search"></i>
                                </button>
                              </div>
                            </form>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th>Amount</th>
                                        <th>Production Date	</th>
                                        <th>End Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $pharmacys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td data-title='#'><?php echo e($loop->iteration); ?></td>
                                        <td data-title='Name'><?php echo e($item->name); ?></td>
                                        <td data-title='Price'><?php echo e($item->dollar()); ?></td>
                                        <td data-title='Amount'><?php echo e($item->amount); ?></td>
                                        <td data-title='Production Date'><?php echo e($item->production_date); ?></td>
                                        <td data-title='End Date'><?php echo e($item->end_date); ?></td>

                                        <td data-title='actions'>
                                            
                                            <a href="<?php echo e(url('/pharmacys/' . $item->id . '/edit')); ?>" title="Edit Teacher"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>

                                            <form method="POST" action="<?php echo e(url('/pharmacys' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete Teacher" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div> <?php echo e($pharmacys->links('pagination::bootstrap-5')); ?></div>

                    </div>
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical - Email\resources\views/admin/pharmacy/index.blade.php ENDPATH**/ ?>