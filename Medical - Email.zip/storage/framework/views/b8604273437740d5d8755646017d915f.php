<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','create'); ?>

<div class="card">
  <div class="card-header">Edit Page</div>
  <div class="card-body">

      <form action="<?php echo e(url('xray/' .$xray->id)); ?> " method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PUT"); ?>
        <label> Patient Name</label></br>
        <input type="text" name="name" id="name" class="form-control" value="<?php echo e($xray->name); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
        <label>Phone</label></br>
        <input type="text" name="phone" id="phone" class="form-control" value="<?php echo e($xray->phone); ?>">
        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
        <label> Date</label></br>
        <input type="Date" name="date" id="date" class="form-control" value="<?php echo e($xray->date); ?>">
        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></br>
        <label>Time</label></br>
        <select  name="time"  class="form-control" >


            <option  value="<?php echo e($xray->time); ?>" >--Choose the Time--</option>
            <option name="time" value="<?php echo e($xray->time); ?>">9:00AM</option>
            <option name="time" value="<?php echo e($xray->time); ?>">9:30AM</option>
            <option name="time" >10:00AM</option>
            <option name="time">10:30AM</option>
            <option name="time">11:00AM</option>
            <option name="time">11:30AM</option>
            <option name="time">12:00PM</option>
            <option name="time">12:30PM</option>
            <option name="time">1:00PM</option>
            <option name="time">1:30PM</option>
            <option name="time">2:00PM</option>
            <option name="time">2:30PM</option>
            <option name="time">3:00PM</option>
            <option name="time">3:30PM</option>
            <option name="time">4:00PM</option>
            <option name="time">4:30PM</option>
            <option name="time">5:00PM</option>

    </select>
    <?php $__errorArgs = ['time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>




        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>


  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical - Email\resources\views/user/Xray/edit.blade.php ENDPATH**/ ?>