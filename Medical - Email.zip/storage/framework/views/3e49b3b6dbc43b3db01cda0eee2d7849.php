<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','create'); ?>

    <div class="formbold-form-wrapper ">
        <?php if(session('success')): ?>
        <div class="alert alert-success"style="padding: 5px" role="alert">
     <?php echo e(session( 'success' )); ?>

        </div>
<?php elseif(session('failure')): ?>
<div class="alert alert-danger" style="padding: 5px" role="alert">
<?php echo e(session( 'failure' )); ?>

</div>
        <?php endif; ?>

        <form action="<?php echo e(route('appointment.store')); ?>" method="POST" class="formNew">
            <?php echo csrf_field(); ?>
            <div class="formbold-mb-5">
                <label for="name" class="formbold-form-label"> Full Name </label>

                <input type="text" name="pid" id="name"  class="formbold-form-input" value=" <?php echo e(Auth::user()->name); ?>" />

            </div>

            <div class="formbold-mb-5">
                <label for="did" class="formbold-form-label"> Name Doctor </label>
                <select  name="did"  class="formbold-form-input" >
                    <option selected>--Choose the Doctor--</option>

                <?php $__currentLoopData = $appointment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($name->specialty=='Dentistry'): ?>

                <option value="<?php echo e($name->id); ?>"><?php echo e($name->name); ?></option>


                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </select>

    </div>

            <div class="flex flex-wrap formbold--mx-3">
                <div class="w-full sm:w-half formbold-px-3">
                    <div class="formbold-mb-5 w-full">
                        <label for="date" class="formbold-form-label"> Date </label>
                        <input type="date" name="date" id="date" class="formbold-form-input" />
                    </div>
                </div>
                <div class="w-full sm:w-half formbold-px-3">
                    <div class="formbold-mb-5">
                        <label for="phone" class="formbold-form-label"> Time </label>
                        <select  name="time"  class="formbold-form-input" >


                            <option >--Choose the Time--</option>
                            <option name="time">9:00AM</option>
                            <option name="time">9:30AM</option>
                            <option name="time">10:00AM</option>
                            <option name="time">10:30AM</option>
                            <option name="time">11:00AM</option>
                            <option name="time">11:30AM</option>
                            <option name="time">12:00PM</option>
                            <option name="time">12:30PM</option>
                            <option name="time">1:00PM</option>
                            <option name="time">1:30PM</option>
                            <option name="time">2:00PM</option>
                            <option name="time">2:30PM</option>
                            <option name="time">3:00PM</option>
                            <option name="time">3:30M</option>
                            <option name="time">4:00PM</option>
                            <option name="time">4:30PM</option>
                            <option name="time">5:00PM</option>

                    </select>


                    </div>
                </div>
            </div>



            <div>
                <button class="formbold-btn" type="submit"> Appointment</button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical - Email\resources\views/user/appointment/create.blade.php ENDPATH**/ ?>