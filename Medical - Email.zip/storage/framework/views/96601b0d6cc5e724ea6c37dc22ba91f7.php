<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','create'); ?>

<div class="card">
  <div class="card-header">Edit Page</div>
  <div class="card-body">

      <form action="<?php echo e(url('doctors/' .$doctors->id)); ?> " method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PUT"); ?>
        <label>Name</label></br>
        <input type="text" name="name" id="name" class="form-control" value="<?php echo e($doctors->name); ?>">
        <label>Mobile</label></br>
        <input type="text" name="phone" id="phone" class="form-control" value="<?php echo e($doctors->phone); ?>">
        <label>Email</label></br>
        <input type="email" name="email" id="email" class="form-control" value="<?php echo e($doctors->email); ?>">
        <label>Password</label></br>
        <input type="password" name="password" id="email" class="form-control" value="<?php echo e($doctors->password); ?>">
        <label>Specialty</label></br>
        <input type="text" name="specialty" id="email" class="form-control" value="<?php echo e($doctors->specialty); ?>">

        <label>Gender</label></br>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" value="Male" value="<?php echo e($doctors->gender); ?>">
            <label class="form-check-label" for="inlineRadio1">Male</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" id="inlineRadio2" value="Female" value="<?php echo e($doctors->gender); ?>">
            <label class="form-check-label" for="inlineRadio2">Female</label>
          </div></br></br>



        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>


  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical - Email\resources\views/admin/doctor/edit.blade.php ENDPATH**/ ?>