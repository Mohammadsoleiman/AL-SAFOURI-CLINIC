<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','index'); ?>

                <div class="card">
                    <div class="card-header">
                        <h2>Pharmacy</h2>
                    </div>
                    <div class="card-body">

                        <br/>
                        <br/>
                        <form method="GET" action="/searchpuser">
                            <div class="input-group d-flex justify-content-end">
                                <div class="form-outline" data-mdb-input-init>
                                  <input type="search" id="form1" class="form-control" name="search"  placeholder="Search"  value="<?php echo e(isset($search)? $search :''); ?>"/>
                                </div>
                                <button type="submit" class="btn-search" data-mdb-ripple-init>
                                  <i class="fas fa-search"></i>
                                </button>
                              </div>
                            </form>
                            <div class="table-responsive ">
                                <table class="table" >
                                <thead>
                                    <tr >
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Price</th>
                                        <th >Amount</th>
                                        <th>Production Date	</th>
                                        <th>End Date</th>
                                        
                                    </tr>
                                </thead>
                                <tbody class="tbody">
                                <?php $__currentLoopData = $pharmacys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr">
                                        <td  data-title='#' style="background: #34AD93"><?php echo e($loop->iteration); ?></td>
                                        <td data-title='Name'><?php echo e($item->name); ?></td>
                                        <td data-title='Price'><?php echo e($item->dollar()); ?></td>
                                        <td data-title='Amount'><?php echo e($item->amount); ?></td>
                                        <td data-title='Production Date'><?php echo e($item->production_date); ?></td>
                                        <td data-title='End Date'><?php echo e($item->end_date); ?></td>


                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div> <?php echo e($pharmacys->links('pagination::bootstrap-5')); ?></div>

                    </div>
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical - Email\resources\views/user/index.blade.php ENDPATH**/ ?>