<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','index'); ?>

                <div class="card h-100">
                    <div class="card-header p-0 mx-1">
                        <h4>All User</h4>
                    </div>
                    <div class="card-body">



                        <br/>
                        <form method="GET" action="/searchr">
                        <div class="input-group d-flex justify-content-end">
                            <div class="form-outline" data-mdb-input-init>
                              <input type="search" id="form1" class="form-control" name="search"  placeholder="Search"  value="<?php echo e(isset($search)? $search :''); ?>"/>
                            </div>
                            <button type="submit"  class="btn-search" data-mdb-ripple-init>
                              <i class="fas fa-search"></i>
                            </button>
                          </div>
                        </form>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>

                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Gender</th>
                                        
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $req; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->role =='user'): ?>
                                    <tr>

                                        <td data-title='ID'><?php echo e($item->id); ?></td>
                                        <td data-title='Gender'><?php echo e($item->name); ?></td>
                                        <td data-title='Email'><?php echo e($item->email); ?></td>
                                        <td data-title='Mobile'><?php echo e($item->phone); ?></td>
                                        <td data-title='Gender'><?php echo e($item->gender); ?></td>
                                        
                                        <td data-title='Date'><?php echo e($item->created_at->toFormattedDateString()); ?></td>


                                        <td data-title='Actions'>
                                            <?php if($item->status ==1): ?>
                                            <a href="<?php echo e(route('users.status.update',['user_id'=> $item->id,'status_code'=> 0])); ?>" title="Edit user"><button class="btn btn-danger btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> enable</button></a>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('users.status.update',['user_id'=> $item->id,'status_code'=> 1])); ?>" title="Edit user"><button class="btn btn-success btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> disable</button></a>
                                            <?php endif; ?>



                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>


                            </table>
                        <div> <?php echo e($req->links('pagination::bootstrap-5')); ?></div>

                        </div>

                    </div>
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical - Email\resources\views/admin/request/index.blade.php ENDPATH**/ ?>