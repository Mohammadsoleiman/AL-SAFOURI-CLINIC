<?php $__env->startSection( 'content' ); ?>
<div class="formbold-main-wrapper">
    <!-- Author: FormBold Team -->
    <!-- Learn More: https://formbold.com -->
    <div class="formbold-form-wrapper">
        
 --}}




        <form action="<?php echo e(route('transfer.data', $sourceData->id)); ?>"method="POST">
            <?php echo csrf_field(); ?>



            <div class="formbold-mb-5">
                                <label for="name" class="formbold-form-label"> Report </label>

                                <textarea type="text" name="detail" id="name"  class="formbold-form-input" ></textarea>
                                
                            </div>

            <div>
                <button class="formbold-btn" type="submit"> Appointment</button>
            </div>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('doctor.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical - Email\resources\views/doctor/history/create.blade.php ENDPATH**/ ?>