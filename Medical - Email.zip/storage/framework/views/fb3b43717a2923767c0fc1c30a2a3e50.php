<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','create'); ?>

<div class="card">
  <div class="card-header">Edit Page</div>
  <div class="card-body">

      <form action="<?php echo e(url('history/' .$history->id)); ?> " method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PUT"); ?>

        <div class="formbold-mb-5">
            <label for="name" class="formbold-form-label"> Report </label>

            <textarea type="text" name="detail" id="name"  class="formbold-form-input" ><?php echo e($history->detail); ?></textarea>
            <?php $__errorArgs = ['detail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="form-error"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>


  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('doctor.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical - Email\resources\views/doctor/history/edit.blade.php ENDPATH**/ ?>