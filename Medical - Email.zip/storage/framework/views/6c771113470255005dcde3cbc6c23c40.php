<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title','create'); ?>

<div class="card ">
  <div class="card-header">Doctor Page</div>
  <div class="card-body">

      <form action="<?php echo e(route('doctors.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label>Name</label></br>
        <input type="text" name="name" id="name" class="form-control">
        <label>Mobile</label></br>
        <input type="text" name="phone" id="phone" class="form-control">
        <label>Email</label></br>
        <input type="email" name="email" id="email" class="form-control">
        <label>Password</label></br>
        <input type="password" name="password" id="email" class="form-control">

        <label>Gender</label></br>
        <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" value="Male" >
            <label class="form-check-label" for="inlineRadio1">Male</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="gender" id="inlineRadio2" value="Female">
            <label class="form-check-label" for="inlineRadio2">Female</label>
          </div></br></br>

        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>

  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Medical\resources\views/admin/doctor/create.blade.php ENDPATH**/ ?>